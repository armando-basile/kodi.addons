# plugin.program.xmltv.updater
## description
Kodi plugin to download (on demand) XMLTV file from Rytec repository.


