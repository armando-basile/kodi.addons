# plugin.program.iptvspecial.updater
## description
Kodi plugin to update iptvspecial live m3u channels list with info to use Rytec XMLTV data.


