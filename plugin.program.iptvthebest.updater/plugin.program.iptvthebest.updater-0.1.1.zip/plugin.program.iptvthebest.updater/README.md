# plugin.program.iptvthebest.updater
## description
Kodi plugin to update iptvthebest live m3u channels list with info to use Rytec XMLTV data.


