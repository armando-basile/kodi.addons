# plugin.program.iptvsuperflussi.updater
## description
Kodi plugin to update iptv superflussi live m3u channels list with info to use XMLTV data.


